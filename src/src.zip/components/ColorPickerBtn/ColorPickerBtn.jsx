import React from 'react';

const ColorPickerBtn = ({color}) => {
  return (
    <div style={{ background: color }}>
    </div>
  );
};

export default ColorPickerBtn;
