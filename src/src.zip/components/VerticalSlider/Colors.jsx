import React from 'react';

const Colors = () => {
    return (
        <div>
            
        </div>
    );
};

export default Colors;
