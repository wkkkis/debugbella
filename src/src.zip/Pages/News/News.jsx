import React from "react";
import BreadCrumbs from "../../components/BreadCrumbs/BreadCrumbs";
// import style from "../../components/NewsCart/NewsCart.module.scss";
// import newsImg from "../../assets/newsimg.png";
// import arrow from "../../assets/lock_nextImg/arrow_brown.png";

const News = () => {

    return (
        <BreadCrumbs/>
        // <div className="list">                
        //     {topicsData.map((item) =>(
        //     <NewsCart key={item.id} item={item} />
            
        //     ))}                
        // </div>
        
    );
};

export default News;
